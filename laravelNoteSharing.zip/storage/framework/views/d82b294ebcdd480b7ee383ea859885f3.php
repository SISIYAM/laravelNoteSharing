<?php $__env->startSection('page-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <?php echo $__env->yieldContent('form-title'); ?>
                </div>
                <?php echo $__env->yieldContent('form-content'); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php if(Session::has('success')): ?>
    <?php $__env->startPush('sweet-alert'); ?>
        <script>
            swal("Success!", "<?php echo e(Session::get('success')); ?>", {
                icon: "success",
                buttons: {
                    confirm: {
                        className: "btn btn-success",
                    },
                },
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php echo $__env->make('admin.layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\laravelNoteSharing\resources\views\admin\layouts\common-form.blade.php ENDPATH**/ ?>
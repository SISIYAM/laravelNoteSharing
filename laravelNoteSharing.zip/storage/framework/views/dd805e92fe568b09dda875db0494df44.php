    <title>Siyam</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
<?php /**PATH D:\laravel\laravelNoteSharing\resources\views/admin/layouts/titileAndLogo.blade.php ENDPATH**/ ?>
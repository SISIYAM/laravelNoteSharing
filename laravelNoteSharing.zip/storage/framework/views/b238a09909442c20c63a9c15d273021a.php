<?php $__env->startSection('page-content'); ?>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <?php if($key == 'university'): ?>
                        <h4 class="card-title">Universities</h4>
                        <a href="<?php echo e(route('admin.add.universities')); ?>"class="btn btn-primary btn-round ms-auto">
                            <i class="fa fa-plus"></i>
                            Add
                        </a>
                    <?php elseif($key == 'materials'): ?>
                        <h4 class="card-title">Materials</h4>
                        <a href="<?php echo e(route('admin.form.materials')); ?>" class="btn btn-primary btn-round ms-auto">
                            <i class="fa fa-plus"></i>
                            Add
                        </a>
                    <?php elseif($key == 'faculties'): ?>
                        <h4 class="card-title">Faculties</h4>
                        <a href="<?php echo e(route('admin.form.faculties')); ?>" class="btn btn-primary btn-round ms-auto">
                            <i class="fa fa-plus"></i>
                            Add
                        </a>
                    <?php elseif($key == 'departments'): ?>
                        <h4 class="card-title">Departments</h4>
                    <?php elseif($key == 'pdfs'): ?>
                        <h4 class="card-title">Pdfs</h4>
                    <?php elseif($key == 'users'): ?>
                        <h4 class="card-title">Users</h4>
                        <a href=""class="btn btn-primary btn-round ms-auto">
                            <i class="fa fa-plus"></i>
                            Add
                        </a>
                    <?php elseif($key == 'materialRequest'): ?>
                        <h4 class="card-title">Requests for materials</h4>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="add-row" class="display table table-striped table-hover">
                        <thead>
                            <tr>
                                <?php $__currentLoopData = $thead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($th); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>

                        <tbody>
                            <?php echo $__env->yieldContent('table-row'); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\laravelNoteSharing\resources\views\admin\layouts\common-table.blade.php ENDPATH**/ ?>